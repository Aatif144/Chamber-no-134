-- CHAMBER NO. 134 — Supabase schema
-- Run this entire file in Supabase SQL Editor on a NEW project.
create extension if not exists pgcrypto;

create table if not exists public.chambers (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 created_by uuid not null references auth.users(id) on delete restrict,
 created_at timestamptz not null default now()
);
create table if not exists public.chamber_members (
 id uuid primary key default gen_random_uuid(),
 chamber_id uuid not null references public.chambers(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null default 'clerk' check (role in ('owner','admin','advocate','clerk','read_only')),
 created_at timestamptz not null default now(),
 unique(chamber_id,user_id)
);
create table if not exists public.clients (
 id uuid primary key default gen_random_uuid(),
 chamber_id uuid not null references public.chambers(id) on delete cascade,
 full_name text not null,
 phone text,
 email text,
 address text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.cases (
 id uuid primary key default gen_random_uuid(),
 chamber_id uuid not null references public.chambers(id) on delete cascade,
 case_number text not null,
 case_type text not null default 'Civil',
 court_name text,
 court_number text,
 judge_name text,
 client_id uuid references public.clients(id) on delete set null,
 opposite_party text,
 opposite_counsel text,
 filing_date date,
 next_date date,
 next_purpose text,
 status text not null default 'Pending',
 total_fee numeric(12,2) not null default 0 check(total_fee>=0),
 notes text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(chamber_id,case_number)
);
create table if not exists public.hearings (
 id uuid primary key default gen_random_uuid(),
 chamber_id uuid not null references public.chambers(id) on delete cascade,
 case_id uuid not null references public.cases(id) on delete cascade,
 hearing_date date not null,
 purpose text,
 order_summary text,
 created_at timestamptz not null default now()
);
create table if not exists public.payments (
 id uuid primary key default gen_random_uuid(),
 chamber_id uuid not null references public.chambers(id) on delete cascade,
 case_id uuid not null references public.cases(id) on delete cascade,
 amount numeric(12,2) not null check(amount>0),
 payment_date date not null default current_date,
 mode text not null default 'UPI',
 notes text,
 created_at timestamptz not null default now()
);
create table if not exists public.case_documents (
 id uuid primary key default gen_random_uuid(),
 chamber_id uuid not null references public.chambers(id) on delete cascade,
 case_id uuid not null references public.cases(id) on delete cascade,
 file_name text not null,
 storage_path text not null,
 document_type text,
 uploaded_by uuid references auth.users(id),
 created_at timestamptz not null default now()
);

create index if not exists cases_chamber_next_date_idx on public.cases(chamber_id,next_date);
create index if not exists hearings_chamber_date_idx on public.hearings(chamber_id,hearing_date);
create index if not exists payments_chamber_date_idx on public.payments(chamber_id,payment_date);
create index if not exists clients_chamber_name_idx on public.clients(chamber_id,full_name);

create or replace function public.is_chamber_member(cid uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.chamber_members m where m.chamber_id=cid and m.user_id=auth.uid()); $$;
create or replace function public.has_chamber_role(cid uuid, allowed text[])
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.chamber_members m where m.chamber_id=cid and m.user_id=auth.uid() and m.role=any(allowed)); $$;

-- Create first chamber and make caller its owner.
create or replace function public.create_chamber(chamber_name text)
returns uuid language plpgsql security definer set search_path=public
as $$
declare new_id uuid;
begin
 if auth.uid() is null then raise exception 'Sign in first'; end if;
 if exists(select 1 from public.chamber_members where user_id=auth.uid()) then
   raise exception 'Your account already belongs to a chamber';
 end if;
 insert into public.chambers(name,created_by) values(coalesce(nullif(trim(chamber_name),''),'CHAMBER NO. 134'),auth.uid()) returning id into new_id;
 insert into public.chamber_members(chamber_id,user_id,role) values(new_id,auth.uid(),'owner');
 return new_id;
end $$;

alter table public.chambers enable row level security;
alter table public.chamber_members enable row level security;
alter table public.clients enable row level security;
alter table public.cases enable row level security;
alter table public.hearings enable row level security;
alter table public.payments enable row level security;
alter table public.case_documents enable row level security;

create policy "members can view own chamber" on public.chambers for select using(public.is_chamber_member(id));
create policy "members can view membership" on public.chamber_members for select using(public.is_chamber_member(chamber_id));
create policy "members can view clients" on public.clients for select using(public.is_chamber_member(chamber_id));
create policy "staff can add clients" on public.clients for insert with check(public.has_chamber_role(chamber_id,array['owner','admin','advocate','clerk']));
create policy "staff can update clients" on public.clients for update using(public.has_chamber_role(chamber_id,array['owner','admin','advocate','clerk'])) with check(public.is_chamber_member(chamber_id));
create policy "admins can delete clients" on public.clients for delete using(public.has_chamber_role(chamber_id,array['owner','admin']));
create policy "members can view cases" on public.cases for select using(public.is_chamber_member(chamber_id));
create policy "staff can add cases" on public.cases for insert with check(public.has_chamber_role(chamber_id,array['owner','admin','advocate','clerk']));
create policy "staff can update cases" on public.cases for update using(public.has_chamber_role(chamber_id,array['owner','admin','advocate','clerk'])) with check(public.is_chamber_member(chamber_id));
create policy "admins can delete cases" on public.cases for delete using(public.has_chamber_role(chamber_id,array['owner','admin']));
create policy "members can view hearings" on public.hearings for select using(public.is_chamber_member(chamber_id));
create policy "staff can add hearings" on public.hearings for insert with check(public.has_chamber_role(chamber_id,array['owner','admin','advocate','clerk']));
create policy "staff can update hearings" on public.hearings for update using(public.has_chamber_role(chamber_id,array['owner','admin','advocate','clerk'])) with check(public.is_chamber_member(chamber_id));
create policy "admins can delete hearings" on public.hearings for delete using(public.has_chamber_role(chamber_id,array['owner','admin']));
create policy "members can view payments" on public.payments for select using(public.is_chamber_member(chamber_id));
create policy "staff can add payments" on public.payments for insert with check(public.has_chamber_role(chamber_id,array['owner','admin','advocate','clerk']));
create policy "admins can update payments" on public.payments for update using(public.has_chamber_role(chamber_id,array['owner','admin'])) with check(public.is_chamber_member(chamber_id));
create policy "admins can delete payments" on public.payments for delete using(public.has_chamber_role(chamber_id,array['owner','admin']));
create policy "members can view documents" on public.case_documents for select using(public.is_chamber_member(chamber_id));
create policy "staff can add documents" on public.case_documents for insert with check(public.has_chamber_role(chamber_id,array['owner','admin','advocate','clerk']));
create policy "admins can delete documents" on public.case_documents for delete using(public.has_chamber_role(chamber_id,array['owner','admin']));

-- Invite another user: first create their Auth account in Supabase Dashboard,
-- then run the INSERT shown in README with their auth.users UUID.
-- Never expose the service_role key in the browser.
grant execute on function public.create_chamber(text) to authenticated;
grant execute on function public.is_chamber_member(uuid) to authenticated;
grant execute on function public.has_chamber_role(uuid,text[]) to authenticated;
